package dad.Model;

public enum Curso {
    Primero_DAM,
    Segundo_DAM,
    Primero_ASIR,
    Segundo_ASIR,

}
