package dad.Controllers;

import dad.Conexion.*;
import dad.Model.Curso;
import javafx.collections.*;
import javafx.fxml.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.util.*;

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;

public class tutorGrupoCreateController implements Initializable {

    @FXML
    private BorderPane root;

    @FXML
    private TextField nombre;

    @FXML
    private ChoiceBox<Integer> IdAlumno;

    @FXML
    private ChoiceBox<Curso> grupoComboBox;

    @FXML
    private Button actualizar;

    @FXML
    private Button cancelar;

    private boolean confirmar = false;

    public tutorGrupoCreateController() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/Tutor_GrupoCreate.fxml"));
            loader.setController(this);
            loader.load();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @FXML
    void onActualizarAction() {
        confirmar = true;
        cerrar();
    }

    @FXML
    void onCancelarAction() {
        confirmar = false;
        cerrar();
    }

    @FXML
    void onLimpiarAction(){
        // Lógica para limpiar campos si es necesario
    }

    private void cerrar() {
        Stage stage = (Stage) root.getScene().getWindow();
        stage.close();
    }

    public BorderPane getRoot() {
        return root;
    }

    public boolean isConfirmar() {
        return confirmar;
    }

    public TextField getNombre() {
        return nombre;
    }

    public ChoiceBox<Integer> getIdAlumno() {
        return IdAlumno;
    }

    public Curso getGrupoSeleccionado() {
        return grupoComboBox.getValue(); // Devuelve el curso seleccionado en el ChoiceBox
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        cargarIdAlumno();  // Cargar los ID de los alumnos
        cargarCurso();      // Cargar los cursos en el ChoiceBox
    }

    private void cargarIdAlumno() {
        String sql = "SELECT Id_Alumno FROM alumno";
        try (Connection connection = Conectar.getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            ObservableList<Integer> alumnos = FXCollections.observableArrayList();
            while (rs.next()) {
                alumnos.add(rs.getInt("Id_Alumno"));
            }
            IdAlumno.setItems(alumnos);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void cargarCurso() {
        // Agregar los valores del enum Curso al ChoiceBox
        grupoComboBox.getItems().setAll(Curso.values());

        // Usar un conversor para mostrar los cursos de forma legible
        grupoComboBox.setConverter(new StringConverter<Curso>() {
            @Override
            public String toString(Curso curso) {
                if (curso == null) {
                    return null;
                }
                // Reemplazar guiones bajos con espacios para una visualización más legible
                return curso.name().replace('_', ' ');
            }

            @Override
            public Curso fromString(String string) {
                return Curso.valueOf(string.replace(' ', '_')); // Convierte el texto a un valor del enum
            }
        });
    }

    public void setRoot(BorderPane root) {
        this.root = root;
    }

    public void setNombre(TextField nombre) {
        this.nombre = nombre;
    }

    public void setIdAlumno(ChoiceBox<Integer> idAlumno) {
        IdAlumno = idAlumno;
    }

    public ChoiceBox<Curso> getGrupoComboBox() {
        return grupoComboBox;
    }

    public void setGrupoComboBox(ChoiceBox<Curso> grupoComboBox) {
        this.grupoComboBox = grupoComboBox;
    }

    public Button getActualizar() {
        return actualizar;
    }

    public void setActualizar(Button actualizar) {
        this.actualizar = actualizar;
    }

    public Button getCancelar() {
        return cancelar;
    }

    public void setCancelar(Button cancelar) {
        this.cancelar = cancelar;
    }

    public void setConfirmar(boolean confirmar) {
        this.confirmar = confirmar;
    }
}
