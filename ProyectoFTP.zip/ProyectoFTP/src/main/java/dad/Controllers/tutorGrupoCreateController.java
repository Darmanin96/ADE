package dad.Controllers;

import dad.Model.Curso;
import javafx.collections.*;
import javafx.fxml.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.*;

import java.net.URL;
import java.util.ResourceBundle;

public class tutorGrupoCreateController implements Initializable {

    @FXML
    private BorderPane root;

    @FXML
    private TextField Nombre;

    @FXML
    private ChoiceBox<Integer> IdAlumno;

    @FXML
    private ComboBox<Curso> grupoComboBox;

    @FXML
    private Button Actualizar;

    @FXML
    private Button Cancelar;

    private boolean confirmar = false;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        grupoComboBox.setItems(FXCollections.observableArrayList(Curso.values()));
    }

    public BorderPane getRoot() {
        return root;
    }

    public boolean isConfirmar() {
        return confirmar;
    }

    public TextField getNombre() {
        return Nombre;
    }

    public ChoiceBox<Integer> getIdAlumno() {
        return IdAlumno;
    }

    public Curso getGrupoSeleccionado() {
        return grupoComboBox.getValue();
    }

    @FXML
    void onActualizarAction() {
        confirmar = true;
        ((Stage) root.getScene().getWindow()).close();
    }

    @FXML
    void onCancelarAction() {
        confirmar = false;
        ((Stage) root.getScene().getWindow()).close();
    }
}
