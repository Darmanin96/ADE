package dad.Controllers;

import dad.Conexion.*;
import dad.Model.*;
import javafx.collections.*;
import javafx.event.*;
import javafx.fxml.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.control.cell.*;
import javafx.scene.layout.*;
import javafx.stage.*;

import java.io.*;
import java.net.*;
import java.sql.*;
import java.util.*;

public class tutorGrupoController implements Initializable {

    @FXML
    private Button Añadir;

    @FXML
    private Button Eliminar;

    @FXML
    private TableColumn<tutorGrupo, Curso> Grupo;

    @FXML
    private TableColumn<tutorGrupo, String> Nombre;

    @FXML
    private AnchorPane detallePanel;

    @FXML
    private TableColumn<tutorGrupo, Integer> idAlumno;

    @FXML
    private TableColumn<tutorGrupo, Integer> idTutor;

    @FXML
    private BorderPane root;

    @FXML
    private TableView<tutorGrupo> tableGrupo;

    private final ObservableList<tutorGrupo> TutorGrupoLista = FXCollections.observableArrayList();

    @FXML
    void onAñadirAction(ActionEvent event) {
        tutorGrupoCreateController tutorGrupoCreateController = new tutorGrupoCreateController();
        Stage stage = new Stage();
        stage.setTitle("Nuevo Tutor Docente");
        stage.setScene(new Scene(tutorGrupoCreateController.getRoot()));
        stage.showAndWait();

        if (tutorGrupoCreateController.isConfirmar()) {
            String nombre = tutorGrupoCreateController.getNombre().getText();
            Curso grupo = Curso.valueOf(tutorGrupoCreateController.getNombre().getText());
            Integer idAlumno = tutorGrupoCreateController.getIdAlumno().getValue();

            int nuevoId = insertarTutorGrupo(nombre, grupo, idAlumno);
            if (nuevoId > 0) {
                cargarTablaTutorGrupo();
            } else {
                Alert alerta = new Alert(Alert.AlertType.ERROR);
                alerta.setTitle("Error");
                alerta.setHeaderText("No se pudo añadir la asignación.");
                alerta.setContentText("Hubo un problema al insertar la asignación en la base de datos.");
                alerta.showAndWait();
            }
        }
    }

    @FXML
    void onEliminarAction(ActionEvent event) {
        tutorGrupo selected = tableGrupo.getSelectionModel().getSelectedItem();
        if (selected != null) {
            Alert alerta = new Alert(Alert.AlertType.CONFIRMATION);
            alerta.setTitle("Confirmación");
            alerta.setHeaderText("¿Desea eliminar esta asignación?");
            alerta.setContentText("Esta acción no puede deshacerse.");

            Optional<ButtonType> option = alerta.showAndWait();
            if (option.isPresent() && option.get() == ButtonType.OK) {
                eliminarTutorGrupo(selected.getId_tutor());
                cargarTablaTutorGrupo();
            }
        }
    }

    private void cargarTablaTutorGrupo() {
        TutorGrupoLista.clear();
        String sql = "SELECT * FROM tutor_grupo";
        try (Connection connection = Conectar.getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                TutorGrupoLista.add(new tutorGrupo(
                        rs.getInt("id_tutor"),
                        rs.getString("nombre"),
                        Curso.valueOf(rs.getString("grupo")), // Convertir String a Enum
                        rs.getInt("id_alumno")
                ));
            }
            tableGrupo.setItems(TutorGrupoLista);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private int insertarTutorGrupo(String nombre, Curso grupo, Integer idAlumno) {
        String sql = "INSERT INTO tutor_grupo (nombre, grupo, id_alumno) VALUES (?, ?, ?)";
        try (Connection conn = Conectar.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, nombre);
            stmt.setString(2, grupo.name()); // Guardar el Enum como String
            stmt.setInt(3, idAlumno);
            return stmt.executeUpdate(); // Ejecuta la inserción
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }

    private void eliminarTutorGrupo(int tutorGrupoId) {
        String sql = "DELETE FROM tutor_grupo WHERE id_tutor = ?";
        try (Connection connection = Conectar.getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, tutorGrupoId);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Asignación eliminada correctamente.");
            } else {
                System.out.println("No se encontró la asignación.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void cargar(tutorGrupo TutorGRUPO) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/Tutor_Grupo.fxml"));
            Pane pane = loader.load();
            tutorGrupoSelectedController tutorGrupoSelectedController = loader.getController();
            tutorGrupoSelectedController.obtenerTutor(TutorGRUPO);
            detallePanel.getChildren().clear();
            detallePanel.getChildren().add(pane);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        idTutor.setCellValueFactory(new PropertyValueFactory<>("idTutor"));
        idAlumno.setCellValueFactory(new PropertyValueFactory<>("idAlumno"));
        Nombre.setCellValueFactory(new PropertyValueFactory<>("nombre"));

        Grupo.setCellValueFactory(cellData -> cellData.getValue().grupoProperty());
        Grupo.setCellFactory(column -> new TableCell<>() {

            protected void updateItem(Curso grupo, boolean empty) {
                super.updateItem(grupo, empty);
                if (empty || grupo == null) {
                    setText(null);
                } else {
                    setText(grupo.name());
                }
            }
        });

        cargarTablaTutorGrupo();
    }
}
