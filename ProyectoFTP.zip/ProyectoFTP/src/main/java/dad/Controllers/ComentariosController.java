package dad.Controllers;

import dad.Conexion.*;
import dad.Model.*;
import javafx.collections.*;
import javafx.event.*;
import javafx.fxml.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.control.cell.*;
import javafx.scene.layout.*;
import javafx.stage.*;

import java.io.*;
import java.net.*;
import java.sql.*;
import java.time.*;
import java.util.*;

public class ComentariosController implements Initializable {

    @FXML
    private Button Añadir;

    @FXML
    private TableColumn<Comentarios, String> Comentario;

    @FXML
    private Button Eliminar;

    @FXML
    private TableColumn<Comentarios, LocalDate> Fecha;

    @FXML
    private AnchorPane detallePanel;

    @FXML
    private TableColumn<Comentarios, Integer> idComentario;

    @FXML
    private TableColumn<Comentarios, Integer> idEmpresa;

    @FXML
    private BorderPane root;

    @FXML
    private TableView<Comentarios> tableComentarios;

    private ObservableList<Comentarios> comentariosList = FXCollections.observableArrayList();


    @FXML
    void onAñadirAction(ActionEvent event) {
        ComentariosCreateController comentariosCreateController = new ComentariosCreateController();
        Stage stage = new Stage();
        stage.setTitle("Nuevos Comentarios");
        stage.setScene(new Scene(comentariosCreateController.getRoot()));
        stage.showAndWait();

        if (comentariosCreateController.isConfirmar()) {
            String comentarios = comentariosCreateController.getComentario().getText();
            LocalDate fecha = comentariosCreateController.getFecha().getValue();
            Integer idEmpresa = comentariosCreateController.getIdEmpresa().getValue();

            if (idEmpresa != null) {
                int nuevoId = insertarComentarios(comentarios, fecha, idEmpresa);
                if (nuevoId > 0) {
                    cargarTablaComentarios();
                } else {
                    mostrarError("No se pudo añadir el comentario.", "Hubo un problema al insertar el comentario en la base de datos.");
                }
            } else {
                mostrarError("Falta seleccionar la empresa.", "Por favor, selecciona una empresa antes de continuar.");
            }
        }
    }

    private int insertarComentarios(String comentarios, LocalDate fecha, Integer idEmpresa) {
        String sql = "INSERT INTO comentarios_empresa(Comentario, Fecha_Comentario, Id_Empresa) VALUES(?, ?, ?)";

        try (Connection connection = Conectar.getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, comentarios);
            stmt.setString(2, fecha.toString());
            stmt.setInt(3, idEmpresa);
            int i = stmt.executeUpdate();
            if (i > 0) {
                try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        return generatedKeys.getInt(1);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            mostrarError("Error al insertar comentario", "Hubo un problema al insertar el comentario: " + e.getMessage());
        }
        return -1;
    }

    @FXML
    void onEliminarAction(ActionEvent event) {
        Comentarios comentarioSeleccionado = tableComentarios.getSelectionModel().getSelectedItem();
        if (comentarioSeleccionado != null) {
            eliminarComentario(comentarioSeleccionado.getIdComentario());
            cargarTablaComentarios();
        } else {
            mostrarError("No se seleccionó comentario", "Por favor, selecciona un comentario para eliminar.");
        }
    }

    private void eliminarComentario(int comentarioId) {
        String sql = "DELETE FROM comentarios_empresa WHERE Id_Comentario = ?";

        try (Connection connection = Conectar.getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, comentarioId);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Comentario eliminado con éxito.");
            } else {
                mostrarError("Error", "No se encontró el comentario para eliminar.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            mostrarError("Error al eliminar comentario", "Hubo un problema al eliminar el comentario: " + e.getMessage());
        }
    }

    private void mostrarError(String title, String content) {
        Alert alerta = new Alert(Alert.AlertType.ERROR);
        alerta.setTitle("Error");
        alerta.setHeaderText(title);
        alerta.setContentText(content);
        alerta.showAndWait();
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        // Configuración de las columnas usando PropertyValueFactory
        Comentario.setCellValueFactory(new PropertyValueFactory<>("comentario"));
        Fecha.setCellValueFactory(new PropertyValueFactory<>("fechaComentario"));
        idEmpresa.setCellValueFactory(new PropertyValueFactory<>("idEmpresa"));

        cargarTablaComentarios();
        tableComentarios.setItems(comentariosList);

        // Configuración para seleccionar detalles de un comentario
        tableComentarios.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            detallePanel.setVisible(newValue != null);
            if (newValue != null) {
                cargar(newValue);
            }
        });
    }

    public void cargar(Comentarios comentarioSeleccionado) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/ComentarioSelectedView.fxml"));
            Pane pane = loader.load();
            ComentariosSelectedController comentariosSelectedController = loader.getController();
            comentariosSelectedController.obtenerComentario(comentarioSeleccionado);
            detallePanel.getChildren().clear();
            detallePanel.getChildren().add(pane);
        } catch (IOException e) {
            e.printStackTrace();
            mostrarError("Error al cargar detalle", "Hubo un problema al cargar los detalles del comentario.");
        }
    }

    public void cargarTablaComentarios() {
        comentariosList.clear();
        String sql = "SELECT * FROM comentarios_empresa";
        try (Connection connection = Conectar.getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                comentariosList.add(new Comentarios(
                        rs.getInt("Id_Comentario"),
                        rs.getString("Comentario"),
                        rs.getDate("Fecha_Comentario").toLocalDate(),
                        rs.getInt("Id_Empresa")
                ));
            }
            tableComentarios.setItems(comentariosList);
        } catch (SQLException e) {
            e.printStackTrace();
            mostrarError("Error al cargar comentarios", "Hubo un problema al cargar los comentarios desde la base de datos.");
        }
    }
}
