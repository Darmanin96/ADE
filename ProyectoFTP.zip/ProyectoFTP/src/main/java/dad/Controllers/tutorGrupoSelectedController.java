package dad.Controllers;

import dad.Model.*;
import javafx.event.*;
import javafx.fxml.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;

import java.net.*;
import java.util.*;

public class tutorGrupoSelectedController implements Initializable {

    @FXML
    private Button Actualizar;

    @FXML
    private Button Cancelar;

    @FXML
    private ChoiceBox<Curso> Grupo;

    @FXML
    private ChoiceBox<Integer> IdAlumno;

    @FXML
    private Button Limpiar;

    @FXML
    private TextField Nombre;

    @FXML
    private BorderPane root;

    private tutorGrupo currentTutorGrupo; // Para almacenar el tutorGrupo seleccionado

    private boolean confirmar = false;

    @FXML
    void onActualizarAction(ActionEvent event) {
        if (currentTutorGrupo != null) {
            currentTutorGrupo.setNombre(Nombre.getText());
            currentTutorGrupo.se(Grupo.getValue());
            currentTutorGrupo.setIdAlumno(IdAlumno.getValue());
            confirmar = true;

            Alert alerta = new Alert(Alert.AlertType.INFORMATION);
            alerta.setTitle("Actualización");
            alerta.setHeaderText("Tutor Grupo Actualizado");
            alerta.setContentText("Los cambios se han guardado correctamente.");
            alerta.showAndWait();

            closeWindow();
        } else {
            Alert alerta = new Alert(Alert.AlertType.WARNING);
            alerta.setTitle("Advertencia");
            alerta.setHeaderText("No hay datos cargados");
            alerta.setContentText("Por favor, seleccione un tutor grupo válido antes de actualizar.");
            alerta.showAndWait();
        }
    }

    @FXML
    void onLimpiarAction(ActionEvent event) {
        Nombre.clear();
        Grupo.getSelectionModel().clearSelection();
        IdAlumno.getSelectionModel().clearSelection();
    }

    @FXML
    void ónCancelarAction(ActionEvent event) {
        confirmar = false;
        closeWindow();
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        // Inicializar ChoiceBox de grupos con valores del enum Curso
        Grupo.getItems().setAll(Curso.values());

        // Simulación de IDs de alumnos
        // En un caso real, esto se cargaría desde la base de datos
        IdAlumno.getItems().setAll(1, 2, 3, 4, 5);
    }

    /**
     * Método para cargar la información del tutor grupo seleccionado.
     */
    public void obtenerTutor(tutorGrupo tutor) {
        if (tutor != null) {
            currentTutorGrupo = tutor;

            // Llenar los campos con la información del tutor seleccionado
            Nombre.setText(tutor.getNombre());
            Grupo.setValue(tutor.getGrupo());
            IdAlumno.setValue(tutor.getId_tutor());
        }
    }

    /**
     * Método para cerrar la ventana actual.
     */
    private void closeWindow() {
        root.getScene().getWindow().hide();
    }

    /**
     * Indica si la acción fue confirmada.
     * @return true si se actualizó, false en caso contrario.
     */
    public boolean isConfirmar() {
        return confirmar;
    }
}
