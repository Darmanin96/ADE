package dad.Controllers;

import dad.Conexion.*;
import dad.Model.*;
import javafx.event.*;
import javafx.fxml.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.*;

import java.net.*;
import java.sql.*;
import java.util.*;

public class EmpresaSelectedController implements Initializable {

    @FXML
    private Button Actualizar;

    @FXML
    private Button Cancelar;

    @FXML
    private TextField Correo;

    @FXML
    private TextField Direccion;

    @FXML
    private TextField Especialidad;

    @FXML
    private Button Limpiar;

    @FXML
    private TextField Nombre;

    @FXML
    private CheckBox Participa;

    @FXML
    private Spinner<Integer> Plazas;

    @FXML
    private TextField Telefono;

    @FXML
    private BorderPane root;

    private Empresa empresa;


    @FXML
    void onActualizarAction(ActionEvent event) {
        // Obtener los valores de los campos
        String nombre = Nombre.getText();
        String correo = Correo.getText();
        String direccion = Direccion.getText();
        String especialidad = Especialidad.getText();
        String telefono = Telefono.getText();
        Integer plazasReal = Plazas.getValue();
        Boolean participa = Participa.isSelected();
        if (nombre.isEmpty() || correo.isEmpty() || direccion.isEmpty() || especialidad.isEmpty() || telefono.isEmpty() || plazasReal == null) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Campos Vacíos");
            alert.setHeaderText("Hay campos vacíos");
            alert.setContentText("Por favor, rellena todos los campos.");
            alert.showAndWait();
            return;
        }

        String sql = "UPDATE empresas SET Nombre=?, Direccion=?, Especialidad=?, Telefono=?, Correo=?, Participa=?, Plazas=? WHERE Id_Empresa=?";
        try (Connection con = Conectar.getConnection();
             PreparedStatement stmt = con.prepareStatement(sql)) {

            stmt.setString(1, nombre);
            stmt.setString(2, direccion);
            stmt.setString(3, especialidad);
            stmt.setString(4, telefono);
            stmt.setString(5, correo);
            stmt.setBoolean(6, participa);
            stmt.setInt(7, plazasReal);
            stmt.setInt(8, empresa.getId_Empresa());  // Usamos el ID de la empresa actual

            // Ejecutar la actualización
            int rowsUpdated = stmt.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("La empresa ha sido actualizada con éxito.");
                // Aquí podrías cerrar la ventana o dar un feedback al usuario
            } else {
                System.err.println("No se encontró una empresa con ese ID.");
            }

        } catch (Exception e) {
            System.err.println("Error al actualizar la empresa: " + e.getMessage());
            // Manejo de errores
        }
    }


    @FXML
    void onCancelarAction(ActionEvent event) {
        cerrar();
    }


    private void cerrar(){
        Stage stage = (Stage) root.getScene().getWindow();
        stage.close();
    }

    @FXML
    void onLimpiarAction(ActionEvent event) {
        limpiar();
    }

    private void limpiar() {
        // Limpiar campos de texto
        Nombre.setText("");
        Correo.setText("");
        Direccion.setText("");
        Especialidad.setText("");
        Telefono.setText("");

        // Limpiar CheckBox (restablecerlo a no seleccionado)
        Participa.setSelected(false);

        // Limpiar el Spinner dependiendo del estado de Participa
        if (!Participa.isSelected()) {
            // Si no está seleccionado, podemos hacer que el Spinner no tenga un valor válido
            Plazas.getValueFactory().setValue(null);  // Esto hará que el Spinner no tenga valor
        } else {
            // Si está seleccionado, establecemos un valor predeterminado
            Plazas.getValueFactory().setValue(1);  // Valor por defecto cuando participa
        }
    }


    @Override
    public void initialize(URL location, ResourceBundle resources) {

    }


    public void obtenerEmpresa(Empresa empresa) {
        if (empresa != null) {
            this.empresa = empresa;
            Nombre.textProperty().bindBidirectional(empresa.nombreProperty());
            Direccion.textProperty().bindBidirectional(empresa.direccionProperty());
            Correo.textProperty().bindBidirectional(empresa.correoProperty());
            Especialidad.textProperty().bindBidirectional(empresa.especialidadProperty());
            Telefono.textProperty().bindBidirectional(empresa.telefonoProperty());
            Participa.selectedProperty().bindBidirectional(empresa.participaProperty());

        }
    }

    public Button getActualizar() {
        return Actualizar;
    }

    public void setActualizar(Button actualizar) {
        Actualizar = actualizar;
    }

    public Button getCancelar() {
        return Cancelar;
    }

    public void setCancelar(Button cancelar) {
        Cancelar = cancelar;
    }

    public TextField getCorreo() {
        return Correo;
    }

    public void setCorreo(TextField correo) {
        Correo = correo;
    }

    public TextField getDireccion() {
        return Direccion;
    }

    public void setDireccion(TextField direccion) {
        Direccion = direccion;
    }

    public TextField getEspecialidad() {
        return Especialidad;
    }

    public void setEspecialidad(TextField especialidad) {
        Especialidad = especialidad;
    }

    public Button getLimpiar() {
        return Limpiar;
    }

    public void setLimpiar(Button limpiar) {
        Limpiar = limpiar;
    }

    public TextField getNombre() {
        return Nombre;
    }

    public void setNombre(TextField nombre) {
        Nombre = nombre;
    }

    public CheckBox getParticipa() {
        return Participa;
    }

    public void setParticipa(CheckBox participa) {
        Participa = participa;
    }

    public Spinner<Integer> getPlazas() {
        return Plazas;
    }

    public void setPlazas(Spinner<Integer> plazas) {
        Plazas = plazas;
    }

    public Empresa getEmpresa() {
        return empresa;
    }

    public void setEmpresa(Empresa empresa) {
        this.empresa = empresa;
    }

    public TextField getTelefono() {
        return Telefono;
    }

    public void setTelefono(TextField telefono) {
        Telefono = telefono;
    }

    public BorderPane getRoot() {
        return root;
    }

    public void setRoot(BorderPane root) {
        this.root = root;
    }


}
