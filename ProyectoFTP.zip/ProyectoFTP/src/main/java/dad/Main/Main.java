package dad.Main;

import javafx.application.*;

public class Main {
    public static void main(String[] args) {
        Application.launch(ProyectoFTP.class,args);
    }
}
